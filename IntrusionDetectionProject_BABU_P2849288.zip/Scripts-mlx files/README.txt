
data_preprocessing.m

To load the dataset from the "../Dataset" directory, simply update the path in the readtable function. Here’s the updated data_preprocessing.m file:
===========

File: data_normalization.m
Explanation of Code Steps
Loading Data: Load processed_data.mat from the outputs directory.
Handling Missing Values:
Replace NaN values in dataInputs with column means.
Replace any NaN values in dataTargets with the mode of the target values.
Data Normalization:
Normalize dataInputs to scale each feature to the range [0, 1].
Saving Normalized Data: Save dataInputs and dataTargets as normalized_data.mat for the next step.
Each step includes progress messages to provide real-time feedback on what’s happening, making it easy to track progress.


=========
File: split_data.m

Explanation of Code Steps
Loading Data: Load normalized_data.mat from the outputs directory.
Shuffling Data:
Shuffle both dataInputs and dataTargets using a random permutation of indices.
Splitting Data:
Split 80% of the data for training and 20% for testing based on the shuffled data.
Saving Data:
Save trainingInputs and trainingTargets as training_data.mat.
Save testInputs and testTargets as test_data.mat.
Progress messages are included at each step to ensure clear tracking of the data preparation process.

=====
File: bayesian_optimization.m

Explanation of Code Steps
Loading Data: Load training_data.mat containing trainingInputs and trainingTargets.
Defining Hyperparameter Space:
Specify the range and types of hyperparameters for learning rate, momentum, number of layers, neurons, epochs, activation functions, performance function, and training functions.
Running Bayesian Optimization:
Use the bayesopt function to optimize the hyperparameters using the custom objective_function (which we will define next).
Saving Best Hyperparameters:
Save the optimal hyperparameters found by the optimization process as best_hyperparameters.mat.
Saving Optimization Progress Plot:
Plot the optimization progress and save the plot as optimization_progress.fig.
This step provides output files for the best hyperparameters and the optimization progress plot, helping you keep track of the tuning process.
============

File: objective_function.m

Explanation of Code Steps
Display Current Hyperparameters: Prints the current hyperparameters being evaluated.
Network Configuration:
Sets up the network architecture with the number of hidden layers, neurons, and the specified training and performance functions.
Sets learning rate, momentum, and epochs.
Configures divideFcn to avoid further splitting of training data.
Incompatible Training and Performance Function Check:
Skips incompatible configurations by returning a high error value.
Cross-Validation:
Performs 5-fold cross-validation on the dataset, using cvpartition to divide data.
Trains the model on each fold and records the validation performance.
Calculate Average Error:
Computes the mean error across all folds and returns this as valError, which bayesopt uses to evaluate this configuration.
With this function in place, Bayesian Optimization in bayesian_optimization.m will call objective_function to explore different hyperparameter combinations, aiming to minimize the cross-validation error.

==========
File: train_final_model.m

Explanation of Code Steps
Loading Best Hyperparameters: Load the optimal hyperparameters obtained from Bayesian Optimization.
Loading Training Data: Load training_data.mat with trainingInputs and trainingTargets.
Configuring the Neural Network:
Set the network architecture based on bestParams values.
Configure the training and performance functions, learning rate, momentum, epochs, and activation function.
Training the Network: Train the network on the full training dataset.
Saving the Trained Model: Save the trained model and training record as final_model.mat.
Plotting and Saving Training Progress:
Plot training and validation loss over epochs and save the plot as training_progress.fig.
This step produces two output files:

final_model.mat, containing the trained model and training record.
training_progress.fig, showing the training progress over epochs.

============
File: evaluate_model.m

Explanation of Code Steps
Loading the Model and Test Data: Load final_model.mat and test_data.mat.
Prediction:
Use the trained model to predict labels for testInputs.
Convert raw outputs to binary predictions using a threshold of 0.5.
Calculate and Save Accuracy:
Compute accuracy and save it to metrics.txt.
Confusion Matrix:
Generate a confusion matrix, display it as a heatmap, and save it as confusion_matrix.fig.
Calculate and Save Precision, Recall, and F1 Score:
Calculate additional metrics (precision, recall, and F1 score) and append them to metrics.txt.
ROC Curve and AUC:
Plot the ROC curve and calculate AUC. Save the plot as roc_curve.fig.
This step provides detailed evaluation of the model’s performance, with saved plots and metrics that can be used for further analysis.